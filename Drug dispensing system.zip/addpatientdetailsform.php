<?php

$server = "localhost";
$username = "root";
$password = "";
$dbname = "drug_dispensing";

$conn = mysqli_connect($server, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    if (!empty($_POST['SSN']) && !empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['phoneNumber']) && !empty($_POST['age'])) {
        $SSN = $_POST['SSN'];
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phoneNumber = $_POST['phoneNumber'];
        $age = $_POST['age'];

        $query = "INSERT INTO patient (SSN, name, email_address, phone_number, age) VALUES ('$SSN', '$name', '$email', '$phoneNumber', '$age')";

        $run = mysqli_query($conn, $query);

        if ($run) {
            
            echo "Form submitted successfully";
            print_r($_POST);
           
        } else {
            echo "Form not submitted";
        }
    } else {
        echo "All fields are required";
    }
  
}

mysqli_close($conn);

?>
