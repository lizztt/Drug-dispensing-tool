<!DOCTYPE html>
<html>
<head>
    <title>Welcome, Doctor</title>
    <style>
        .header {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="header">
        <?php
        session_start(); // Start the session

        $host = "localhost";
        $username = "root";
        $password = "";
        $dbname = "drug_dispensing";

        // Create a new connection
        $conn = new mysqli($host, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Retrieve the doctor's first name and last name from the database
        // $SSN = $_SESSION['name']; // Commented out, assuming this line caused the error

        // Assuming the session variable 'name' is set correctly, modify the line above to:
        $SSN = $_SESSION['name'] ?? '';

        $query = "SELECT Fname, Lname FROM doctors WHERE SSN = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $SSN);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        if ($row) {
            $Fname = $row['Fname'];
            $Lname = $row['Lname'];

            echo "<h2>Welcome, Dr. $Fname $Lname</h2>";
        } else {
            echo "<h2>Welcome, Doctor</h2>";
        }

        $conn->close();
        ?>
    </div>

    <center>
        <h3>Actions:</h3>

        <!-- Add/Update Doctor Information form -->
        <form action="add_update_doctor_info.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $SSN; ?>">
            <input type="submit" value="Add/Update Doctor Information">
        </form>

        <!-- View Patient Information form -->
        <form action="view_patient_info.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $SSN; ?>">
            <input type="submit" value="View Patient Information">
        </form>

        <!-- View Prescription History form -->
        <form action="view_prescription_history.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $SSN; ?>">
            <input type="submit" value="View Prescription History">
        </form>

        <!-- Prescribe Medicine for Patients form -->
        <form action="prescribe_medicine.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $SSN; ?>">
            <input type="submit" value="Prescribe Medicine for Patients">
        </form>

        <!-- View Pharmacy Information form -->
        <form action="view_pharmacy_info.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $SSN; ?>">
            <input type="submit" value="View Pharmacy Information">
        </form>
    </center>
</body>
</html>
