<!DOCTYPE html>
<html>
<head>
    <title>Welcome, Patient Admin</title>
    <style>
        body {
            background-color: black;
            color: orange;
            font-family: Arial, sans-serif;
        }
        
        .header {
            text-align: center;
        }
        
        h2 {
            color: orange;
        }
        
        h3 {
            color: orange;
            margin-top: 20px;
            text-align: center;
        }
        
        center {
            margin-top: 20px;
        }
        
        form {
            display: inline-block;
            margin-right: 10px;
        }
        
        input[type="submit"] {
            background-color: orange;
            color: black;
            border: none;
            padding: 10px 20px;
            margin-top: 10px;
            cursor: pointer;
            border-radius: 4px;
        }
        
        input[type="submit"]:hover {
            background-color: #FF8C00;
        }
    </style>
</head>
<body>
    <div class="header">
        <?php
        session_start(); // Start the session

        $host = "localhost";
        $username = "root";
        $password = "";
        $dbname = "drug_dispensing";

        // Create a new connection
        $conn = new mysqli($host, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Retrieve the patient's first name and last name from the database
        $SSN = $_SESSION['name'] ?? '';

        $query = "SELECT Fname, Lname FROM patients WHERE SSN = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $SSN);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        if ($row) {
            $Fname = $row['Fname'];
            $Lname = $row['Lname'];

            echo "<h2>Welcome, $Fname $Lname</h2>";
        } else {
            echo "<h2>Welcome, Patient Admin</h2>";
        }

        $conn->close();
        ?>
    </div>

    <center>
        <h3>Actions:</h3>

        <!-- Add/Update Patient Information form -->
        <form action="add_update_patient_info.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $SSN; ?>">
            <input type="submit" value="Add/Update Patient Information">
        </form>

        <!-- View Patient Information form -->
        <form action="view_patient_info.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $SSN; ?>">
            <input type="submit" value="View Patient Information">
        </form>

        <!-- View Prescription Given form -->
        <form action="view_prescription.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $SSN; ?>">
            <input type="submit" value="View Prescription Given">
        </form>

        <!-- Ask for Prescription Refill form -->
        <form action="prescription_refill.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $SSN; ?>">
            <input type="submit" value="Ask for Prescription Refill">
        </form>

        <!-- View Pharmacy Details form -->
        <form action="view_pharmacy_details.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $SSN; ?>">
            <input type="submit" value="View Pharmacy Details">
        </form>
    </center>
</body>
</html>
