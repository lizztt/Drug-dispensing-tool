<!DOCTYPE html>
<html>
<head>
    <title>View Prescriptions</title>
   
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 0;
            background-color: black;
            color: orange;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
            border: 1px solid orange; /* Updated border */
        }

        th, td {
            padding: 10px;
            text-align: center;
            border-bottom: 1px solid #ddd;
            color: orange;
            border: 1px solid orange; 
        }

        th {
            background-color: orange;
            color: black;
        }

        td:nth-child(odd) {
            background-color: black;
        }

        td:nth-child(even) {
            background-color: black;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: black; 
            color: orange;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: orange;
        }

        .back-button {
            padding: 10px;
            background-color: orange; 
            color: black; 
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }

        
        .back-button:hover {
            background-color: #FF8C00;
        }

        
        .dispense-form {
            background-color: black;
            margin-top: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .dispense-form input[type="submit"] {
            background-color: orange;
            color: black;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
        }

        .dispense-form input[type="submit"]:hover {
            background-color: #FF8C00;
        }

        /* Style for the dispense button inside the form */
        table form input[type="submit"] {
            background-color: orange;
            color: black;
            border: none;
            padding: 6px 10px;
            cursor: pointer;
            border-radius: 4px;
        }

        table form input[type="submit"]:hover {
            background-color: #FF8C00;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Prescription History</h2>

        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "drug_dispensing";

        $conn = mysqli_connect($servername, $username, $password, $database);

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Pagination variables
        $recordsPerPage = 5;
        $page = isset($_GET['page']) ? $_GET['page'] : 1;
        $offset = ($page - 1) * $recordsPerPage;

        // Retrieve total number of records
        $totalRecordsQuery = "SELECT COUNT(*) AS total FROM prescription";
        $totalRecordsResult = $conn->query($totalRecordsQuery);
        $totalRecords = $totalRecordsResult->fetch_assoc()['total'];

        // Calculate total number of pages
        $totalPages = ceil($totalRecords / $recordsPerPage);

        // Retrieve limited records for the current page
        $sql = "SELECT * FROM prescription LIMIT $offset, $recordsPerPage";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            echo "<table>";
            echo "<tr>
                    <th>Prescription ID</th>
                    <th>Drug Name</th>
                    <th>Quantity</th>
                    <th>Patient SSN</th>
                    <th>Doctor SSN</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Actions</th>
                  </tr>";

            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row['prescription_ID'] . "</td>
                        <td>" . $row['drug_name'] . "</td>
                        <td>" . $row['quantity'] . "</td>
                        <td>" . $row['patient_SSN'] . "</td>
                        <td>" . $row['doctor_SSN'] . "</td>
                        <td>" . $row['start_date'] . "</td>
                        <td>" . $row['end_date'] . "</td>
                        <td>
                            <form action='dispensedrugs.php' method='POST'>
                                <!-- Hidden input fields with prescription information -->
                                <input type='hidden' name='prescription_ID' value='" . $row['prescription_ID'] . "'>
                                <input type='hidden' name='drug_id' value='" . $row['drug_id'] . "'>
                                <input type='hidden' name='drug_name' value='" . $row['drug_name'] . "'>
                                <input type='hidden' name='quantity' value='" . $row['quantity'] . "'>
                                <input type='hidden' name='patientSSN' value='" . $row['patient_SSN'] . "'>
                                <input type='hidden' name='doctorSSN' value='" . $row['doctor_SSN'] . "'>
                                <input type='hidden' name='start_date' value='" . $row['start_date'] . "'>
                                <input type='hidden' name='end_date' value='" . $row['end_date'] . "'>
                                
                                <input type='submit' value='Dispense'>
                            </form>
                        </td>
                      </tr>";
            }

            echo "</table>";
        } else {
            echo "<h2>No Prescription History Found</h2>";
        }

        $conn->close();
        ?>

        <?php if ($totalPages > 1): ?>
            <div>
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo ($page - 1); ?>">Previous</a>
                <?php endif; ?>
                
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <?php if ($i == $page): ?>
                        <span><?php echo $i; ?></span>
                    <?php else: ?>
                        <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
                
                <?php if ($page < $totalPages): ?>
                    <a href="?page=<?php echo ($page + 1); ?>">Next</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <button class="back-button" onclick="goBack()">Back</button>
    </div>

    <script>
        function goBack() {
            window.location.href = "pharmacist.php";
        }
    </script>
</body>
</html>
