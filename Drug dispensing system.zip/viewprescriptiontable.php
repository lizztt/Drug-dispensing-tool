<!DOCTYPE html>
<html>
<head>
    <title>DRUG DISPENSING TOOL</title>
    <style>
        table {
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid black;
            padding: 5px;
        }
    </style>
</head>
<body>
    <h2>PRESCRPTION TABLE</h2>
    <?php

        //Establish connection to the database
        require_once ("connect.php");

        // Query your database table
        $sql = "SELECT * FROM prescription";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output the table header
            echo "<table>";
            echo "<tr>";
            $field_names = $result->fetch_fields();
            foreach ($field_names as $field) {
                echo "<th>" . $field->name . "</th>";
            }
            echo "</tr>";

            // Output the table rows
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                foreach ($row as $value) {
                    echo "<td>" . $value . "</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "No data found.";
        }

        // Close the database connection
        $conn->close();
    ?>
</body>
</html>
