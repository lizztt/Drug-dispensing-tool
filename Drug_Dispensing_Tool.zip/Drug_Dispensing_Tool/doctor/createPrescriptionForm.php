<?php

$server = "localhost";
$username = "root";
$password = "";
$dbname = "Drug_Dispensing_Tool";

$conn = mysqli_connect($server, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['submit'])) {
    if (!empty($_POST['date']) && !empty($_POST['quantity']) && !empty($_POST['patientSSN']) && !empty($_POST['doctorSSN']) && !empty($_POST['tradeName'])) {
        $date = $_POST['date'];
        $quantity = $_POST['quantity'];
        $patientSSN = $_POST['patientSSN'];
        $doctorSSN = $_POST['doctorSSN'];
        $tradeName = $_POST['tradeName'];

        $query = "INSERT INTO prescription (date, quantity, patientSSN, doctorSSN, tradeName) VALUES ('$date', '$quantity', '$patientSSN', '$doctorSSN', '$tradeName')";

        $run = mysqli_query($conn, $query);

        if ($run) {
            
            echo "Form submitted successfully";
            print_r($_POST);
           
        } else {
            echo "Form not submitted" . mysqli_error($conn);
        }
    } else {
        echo "All fields are required";
    }
  
}

mysqli_close($conn);

?>
