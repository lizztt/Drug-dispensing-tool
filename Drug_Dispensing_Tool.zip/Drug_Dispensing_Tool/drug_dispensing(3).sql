-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 23, 2023 at 09:21 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drug_dispensing`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
-- Error reading structure for table drug_dispensing.admin: #1142 - SHOW command denied to user &#039;&#039;@&#039;localhost&#039; for table `drug_dispensing`.`admin`
-- Error reading data for table drug_dispensing.admin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `drug_dispensing`.`admin`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--
-- Error reading structure for table drug_dispensing.doctors: #1142 - SHOW command denied to user &#039;&#039;@&#039;localhost&#039; for table `drug_dispensing`.`doctors`
-- Error reading data for table drug_dispensing.doctors: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `drug_dispensing`.`doctors`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--
-- Error reading structure for table drug_dispensing.patients: #1142 - SHOW command denied to user &#039;&#039;@&#039;localhost&#039; for table `drug_dispensing`.`patients`
-- Error reading data for table drug_dispensing.patients: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `drug_dispensing`.`patients`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `pharmacists`
--
-- Error reading structure for table drug_dispensing.pharmacists: #1142 - SHOW command denied to user &#039;&#039;@&#039;localhost&#039; for table `drug_dispensing`.`pharmacists`
-- Error reading data for table drug_dispensing.pharmacists: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `drug_dispensing`.`pharmacists`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `pharm_comp_admin`
--
-- Error reading structure for table drug_dispensing.pharm_comp_admin: #1142 - SHOW command denied to user &#039;&#039;@&#039;localhost&#039; for table `drug_dispensing`.`pharm_comp_admin`
-- Error reading data for table drug_dispensing.pharm_comp_admin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `drug_dispensing`.`pharm_comp_admin`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `supervisors`
--
-- Error reading structure for table drug_dispensing.supervisors: #1142 - SHOW command denied to user &#039;&#039;@&#039;localhost&#039; for table `drug_dispensing`.`supervisors`
-- Error reading data for table drug_dispensing.supervisors: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `drug_dispensing`.`supervisors`&#039; at line 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
