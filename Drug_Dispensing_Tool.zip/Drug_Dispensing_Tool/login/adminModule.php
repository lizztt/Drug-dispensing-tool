<!DOCTYPE html>
<html>
<head>
    <title>Welcome, Admin</title>
    <style>
        .header {
            text-align: right;
        }
        .actions {
            margin-top: 20px;
        }
        .actions form {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="header">
        <?php
        session_start(); // Start the session

        $host = "localhost";
        $username = "root";
        $password = "";
        $dbname = "drug_dispensing";

        // Create a new connection
        $conn = new mysqli($host, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Retrieve the admin's first name and last name from the database
        $SSN = $_SESSION['name'];

        $query = "SELECT Fname, Lname FROM admin WHERE SSN = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $SSN);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        if ($row) {
            $Fname = $row['Fname'];
            $Lname = $row['Lname'];

            echo "<h2>Welcome, admin. $Fname $Lname</h2>";
        } else {
            echo "<h2>Welcome, admin</h2>";
        }

        $conn->close();
        ?>
    </div>

    <div class="actions">
        <form action="http://localhost/myproject/projects/Drug_Dispensing_Tool/viewpatients/viewpatients.php" method="POST">
            <input type="submit" value="Patients">
        </form>

        <form action="http://localhost/myproject/projects/Drug_Dispensing_Tool/viewdoctors/viewdoctors.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $_SESSION['name']; ?>">
            <input type="submit" value="Doctors">
        </form>

        <form action="http://localhost/myproject/projects/Drug_Dispensing_Tool/viewpharmacists/viewpharmacists.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $_SESSION['name']; ?>">
            <input type="submit" value="Pharmacists">
        </form>

        <form action="http://localhost/myproject/projects/Drug_Dispensing_Tool/viewpharmaceuticalcompanyadmins/viewpharmaceuticalcompanyadmins.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $_SESSION['name']; ?>">
            <input type="submit" value="Pharmaceutical Company Admin">
        </form>

        <form action="http://localhost/myproject/projects/Drug_Dispensing_Tool/viewsupervisors/viewsupervisors.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $_SESSION['name']; ?>">
            <input type="submit" value="Supervisor">
        </form>
    </div>
</body>
</html>
