<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Drug_Dispensing_Tool";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connectioncontact.php
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}
else
{
  echo "Connected successfully";
}
?>