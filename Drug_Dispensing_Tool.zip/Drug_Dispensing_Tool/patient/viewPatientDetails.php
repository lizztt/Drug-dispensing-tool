<?php

require_once("connect.php");

$sql = "SELECT * FROM patient";
$results = $conn -> query($sql);

if (mysqli_num_rows($results) > 0){

    //output data of each row
    while ($row = $results -> fetch_assoc()){
        echo 
        "SSN: ".$row['SSN'] . "Name: " .$row['name'] . 
        "Email Address: " . $row['email_address'] . 
        "Phone Number: " . $row['phone_number'].
        "Age: " . $row['age']."<br>";
    }
}
else {
    echo "No results";
}

$results -> close();
$conn -> close();

?>