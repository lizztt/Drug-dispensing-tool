<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "drug_dispensing";

// Create a new connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}                                                                                                                                                               

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $SSN = $_POST['SSN'];

    
    $query = "DELETE FROM pharm_comp_admin WHERE SSN = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $SSN);
    $stmt->execute();

    
    header("Location: viewpharmaceuticalcompanyadmins.php");
    exit;
}
?>
