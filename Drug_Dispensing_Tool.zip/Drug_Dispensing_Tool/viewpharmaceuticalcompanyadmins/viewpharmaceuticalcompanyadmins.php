<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "drug_dispensing";

// Create a new connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$recordsPerPage = 3;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $recordsPerPage;


$totalRecordsQuery = "SELECT COUNT(*) AS total FROM pharm_comp_admin";
$totalRecordsResult = $conn->query($totalRecordsQuery);
$totalRecords = $totalRecordsResult->fetch_assoc()['total'];


$totalPages = ceil($totalRecords / $recordsPerPage);


$sql = "SELECT * FROM pharm_comp_admin LIMIT $offset, $recordsPerPage";
$result = $conn->query($sql);

?>
<style>
    table {
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }

    th, td {
        border: 1px solid black;
        padding: 8px;
    }
</style>
<table>
    <tr>
        <th>SSN</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Password</th>
        <th>Actions</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()) : ?>
        <tr>
            <td><?php echo $row['SSN']; ?></td>
            <td><?php echo $row['Fname']; ?></td>
            <td><?php echo $row['Lname']; ?></td>
            <td><?php echo $row['password']; ?></td>
            <td>
                <form action="edituser.php" method="POST">
                    <input type="hidden" name="SSN" value="<?php echo $row['SSN']; ?>">
                    <input type="submit" value="Edit">
                </form>
                <form action="deleteuser.php" method="POST">
                    <input type="hidden" name="SSN" value="<?php echo $row['SSN']; ?>">
                    <input type="submit" value="Delete">
                </form>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

<?php if ($totalPages > 1): ?>
    <div>
        <?php if ($page > 1): ?>
            <a href="?page=<?php echo ($page - 1); ?>">Previous</a>
        <?php endif; ?>
        
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <?php if ($i == $page): ?>
                <span><?php echo $i; ?></span>
            <?php else: ?>
                <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
            <?php endif; ?>
        <?php endfor; ?>
        
        <?php if ($page < $totalPages): ?>
            <a href="?page=<?php echo ($page + 1); ?>">Next</a>
        <?php endif; ?>
    </div>
<?php endif; ?>
