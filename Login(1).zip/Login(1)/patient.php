<!DOCTYPE html>
<html>
<head>
    <title>Welcome, Patient</title>
    <style>
        .header {
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="header">
        <?php
        session_start(); // Start the session

        $host = "localhost";
        $username = "root";
        $password = "";
        $dbname = "drug_dispensing";

        // Create a new connection
        $conn = new mysqli($host, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Retrieve the patient's first name and last name from the database
        $SSN = $_SESSION['name'];

        $query = "SELECT Fname, Lname FROM patients WHERE SSN = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $SSN);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        if ($row) {
            $Fname = $row['Fname'];
            $Lname = $row['Lname'];

            echo "<h2>Welcome, $Fname $Lname</h2>";
        } else {
            echo "<h2>Welcome, Patient</h2>";
        }

        $conn->close();
        ?>
    </div>

    <center>
        <h3>Actions:</h3>

        <form action="add_update_patient_info.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $_SESSION['name']; ?>">
            <input type="submit" value="Add/Update Patient Information">
        </form>

        <form action="view_patient_info.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $_SESSION['name']; ?>">
            <input type="submit" value="View Patient Information">
        </form>

        <form action="view_prescription.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $_SESSION['name']; ?>">
            <input type="submit" value="View Prescription Given">
        </form>

        <form action="prescription_refill.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $_SESSION['name']; ?>">
            <input type="submit" value="Ask for Prescription Refill">
        </form>

        <form action="view_pharmacy_details.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $_SESSION['name']; ?>">
            <input type="submit" value="View Pharmacy Details">
        </form>

    </center>
</body>
</html>
