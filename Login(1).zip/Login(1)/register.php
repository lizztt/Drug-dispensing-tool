<?php


$host = "localhost";
$username = "root";
$password = "";
$dbname = "drug_dispensing";

// Create a new connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve user type from the query parameter
$userType = $_POST['userType'];

// Perform basic form validation
if (empty($userType)) {
    echo "Invalid user type.";
    exit;
}

// Retrieve form data
$SSN = $_POST['SSN'];
$Fname = $_POST['Fname'];
$Lname = $_POST['Lname'];
$age = $_POST['age'];
$email_address = $_POST['email_address'];
$phone_number = $_POST['phone_number'];
$password = $_POST['password'];
$confirmPassword = $_POST['Confirm_password'];

// Perform additional validation and database interactions here

// Determine the appropriate table based on the user type
$tableName = "";
switch ($userType) {
    case "patient":
        $tableName = "patients";
        break;
    case "doctor":
        $tableName = "doctors";
        break;
    case "supervisor":
        $tableName = "supervisors";
        break;
    case "pharmacist":
        $tableName = "pharmacists";
        break;
    case "pharmaceuticalcompanyadmin":
        $tableName = "pharm_comp_admin";
        break;
    default:
        echo "Invalid user type.";
        exit;
}

// Prepare and execute the SQL statement to insert data into the appropriate table
$stmt = $conn->prepare("INSERT INTO $tableName (SSN, Fname, Lname, age, email_address, phone_number, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("issisis", $SSN, $Fname, $Lname, $age, $email_address, $phone_number, $password);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo "Registration successful as $userType!";
} else {
    echo "Error occurred. Please try again.";
}

if ($stmt->error) {
    echo "Error: " . $stmt->error;
    exit;
}

// Close the prepared statement and database connection
$stmt->close();
$conn->close();
?>

