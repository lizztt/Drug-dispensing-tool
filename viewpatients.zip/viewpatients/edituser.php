<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "drug_dispensing";

// Create a new connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $SSN = $_POST['SSN'];

    
    $query = "SELECT * FROM patients WHERE SSN = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $SSN);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

   
    if ($row) {
        ?>
        <form action="updateuser.php" method="POST">
            <input type="hidden" name="SSN" value="<?php echo $row['SSN']; ?>">
            <label for="first-name">First Name:</label>
            <input type="text" name="Fname" value="<?php echo $row['Fname']; ?>"><br>
            <label for="last-name">Last Name:</label>
            <input type="text" name="Lname" value="<?php echo $row['Lname']; ?>"><br>
            <label for="password">Password:</label>
            <input type="password" name="password" value="<?php echo $row['password']; ?>"><br>
            <input type="submit" value="Update">
        </form>
        <?php
    } else {
        echo "User not found.";
    }
}
?>
