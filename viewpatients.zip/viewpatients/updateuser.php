<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "drug_dispensing";

// Create a new connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $SSN = $_POST['SSN'];
    $Fname = $_POST['Fname'];
    $Lname = $_POST['Lname'];
    $password = $_POST['password'];

   
    $query = "UPDATE patients SET Fname = ?, Lname = ?, password = ? WHERE SSN = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssi", $Fname, $Lname, $password, $SSN);
    $stmt->execute();

    
    header("Location: viewpatients.php");
    exit;
}
?>
